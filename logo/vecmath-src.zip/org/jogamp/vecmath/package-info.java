/**
 * Provides 3D vector mathematics classes.
 */
package org.jogamp.vecmath;
